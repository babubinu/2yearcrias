﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using MySql.Data.MySqlClient; // Namespace do MySQL
namespace SistemaFullStackApp
{
    public partial class PaginaMovimentacao : Page
    {
        public PaginaMovimentacao()
        {
            InitializeComponent();
            CarregarMovimentacoesDoMySQL();
        }

        private void InitializeComponent()
        {
            throw new NotImplementedException();
        }

        private void CarregarMovimentacoesDoMySQL()
        {
            List<Movimentacoes> lista = new List<Movimentacoes>();

            using (MySqlConnection conn = ConexaoMySQL.ObterConexao())
            {
                try
                {
                    conn.Open();
                    string query = "SELECT Id, Dataa, Tipo, Quantidade FROM Movimentacoes";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                lista.Add(new Movimentacao
                                {
                                    Id = Convert.ToInt32(reader["Id"]),
                                    Dataa = reader["Dataa"].ToString(),
                                    Tipo = Convert.ToDecimal(reader["Tipo"]),
                                    Quantidade = Convert.ToInt32(reader["Quantidade"])
                                });
                            }
                        }
                    }
                    dgMovimentacao.ItemsSource = lista;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro de Conexão MySQL: {ex.Message}");
                }
            }
        }

        // 2. MÉTODOS DE ESCRITA (INSERT com Parâmetros)
        private void SalvarProdutoMySQL(string nome, decimal preco, int estoque)
        {
            string query = "INSERT INTO Movimentacoes (Dataa, Tipo, Quantidade) VALUES (@Dataa, @Tipo, @Quantidade)";

            using (MySqlConnection conn = ConexaoMySQL.ObterConexao())
            {
                try
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        // Parâmetros para evitar SQL Injection
                        cmd.Parameters.AddWithValue("@nome", nome);
                        cmd.Parameters.AddWithValue("@preco", preco);
                        cmd.Parameters.AddWithValue("@estoque", estoque);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Produto salvo com sucesso no MySQL!");
                        CarregarMovimentacoesoMySQL();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao salvar no MySQL: {ex.Message}");
                }
            }
        }
    }

    internal class Movimentacoes
    {
    }
}