﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaFullStackApp
{
    internal class Movimentacao
    {
        public int Id { get; set; }
        public string Dataa { get; set; } = string.Empty;
        public decimal Tipo { get; set; }
        public int Quantidade { get; set; }
    }
}
    