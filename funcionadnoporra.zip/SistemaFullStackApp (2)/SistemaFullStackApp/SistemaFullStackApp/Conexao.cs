﻿using MySql.Data.MySqlClient;

namespace SistemaFullStackApp
{
    public static class ConexaoMySQL
    {
        //String de conexão para o MySQL local
        private static string strConexao =
            "Server=localhost;Database=Fullstack_db;Uid=root;Pwd=;";
        public static MySqlConnection ObterConexao()
        {
            return new MySqlConnection(strConexao);
                }
    }
}
