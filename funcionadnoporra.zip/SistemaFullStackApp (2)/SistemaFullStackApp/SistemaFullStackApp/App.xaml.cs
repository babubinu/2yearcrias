using System.Windows;

namespace SistemaFullStackApp
{
  
    public partial class App : Application
    {
    }
}
