using System.Collections.Generic;
using System.Windows.Controls;

namespace SistemaFullStackApp
{
    public partial class PaginaProdutos : Page
    {
        public PaginaProdutos()
        {
            InitializeComponent();
            CarregarProdutos();
        }

        private void CarregarProdutos()
        {

            List<Produto> listaProdutos = new List<Produto>
            {
                new Produto { Id = 1, Nome = "Iphone 16", Preco = 3.999m, Estoque = 10 },
                new Produto { Id = 2, Nome = "Carregador Iphone", Preco = 200m, Estoque = 5 },
                new Produto { Id = 3, Nome = "Fone de ouvido", Preco = 899.90m, Estoque = 20 },
                new Produto { Id = 4, Nome = "Capinha de celular", Preco = 35m, Estoque = 40 },
                new Produto { Id = 5, Nome = "Pelicula", Preco = 15m, Estoque = 5 },
                new Produto { Id = 6, Nome = "powerbank", Preco = 300m, Estoque = 2 }
            };

            
            dgProdutos.ItemsSource = listaProdutos;
        }
    }
}
