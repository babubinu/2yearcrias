using System.Windows;

namespace SistemaFullStackApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
           
            MainFrame.Navigate(new PaginaHome());
        }

        private void btnMenuHome_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new PaginaHome());
        }

        private void btnMenuProdutos_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new PaginaProdutos());
        }

        private void btnAbrirNovaJanela_Click(object sender, RoutedEventArgs e)
        {
            JanelaNova telaModal = new JanelaNova();

            telaModal.ShowDialog();

        }
    }
}
