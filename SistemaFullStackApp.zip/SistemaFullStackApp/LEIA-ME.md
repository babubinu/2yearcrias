# Sistema Full Stack App (WPF + C# + POO)

Este projeto foi feito seguindo o roteiro da **Aula 2** (Programação Full Stack,
Prof. Hermilo Lunas). Ele mostra, de forma bem simples, como criar uma tela
desktop em C# com **WPF**, usando **Orientação a Objetos (POO)** e navegação
entre telas dentro da mesma janela.

## O que o projeto faz

- Abre uma janela principal com um **menu lateral**.
- No menu, dá para clicar em **"Início"** ou **"Produtos"** e a tela muda
  *dentro* da mesma janela (sem abrir janela nova) — isso é feito com um
  `Frame`, que funciona como uma "moldura" que troca o conteúdo (`Page`).
- Na tela **Produtos**, uma tabela (`DataGrid`) mostra uma lista de objetos
  `Produto` criados em memória (ou seja, POO na prática: cada produto é um
  objeto da classe `Produto`).
- Tem também um botão extra **"Nova Janela (extra)"** que mostra como abrir
  uma janela separada em modo pop-up/modal (Passo 5 do material).

## Como abrir e rodar (passo a passo)

1. Instale o **Visual Studio Community** (gratuito), marcando o pacote de
   carga de trabalho **".NET desktop development"** na instalação.
2. Abra o Visual Studio → **Abrir uma pasta** (ou **Abrir projeto/solução**)
   → selecione a pasta `SistemaFullStackApp` e o arquivo
   `SistemaFullStackApp.csproj`.
3. Espere o Visual Studio restaurar o projeto (barra de progresso embaixo).
4. Aperte **F5** (ou o botão verde ▶ "Iniciar") para rodar.
5. A janela principal deve abrir mostrando a tela de "Início".

## Estrutura dos arquivos (o que cada um faz)

| Arquivo                     | Para que serve |
|------------------------------|----------------|
| `Produto.cs`                 | A classe (modelo) que representa um produto: Id, Nome, Preço, Estoque. **Passo 1**. |
| `MainWindow.xaml` / `.cs`    | A janela principal: tem o menu lateral e o `Frame` que troca as telas. **Passo 3**. |
| `PaginaHome.xaml` / `.cs`    | Tela inicial simples, só de boas-vindas. **Passo 2**. |
| `PaginaProdutos.xaml` / `.cs`| Tela com a tabela (`DataGrid`) que lista os produtos. A lista é criada em C# com `List<Produto>` e depois é "ligada" (`ItemsSource`) na tabela do XAML. **Passo 4**. |
| `JanelaNova.xaml` / `.cs`    | Exemplo de janela separada, aberta com `.ShowDialog()` (modal). **Passo 5**. |
| `App.xaml` / `.cs`           | Arquivo que o WPF usa para saber qual janela abrir primeiro (`MainWindow`). |
| `SistemaFullStackApp.csproj` | Arquivo de configuração do projeto (diz que é um app WPF em .NET). |

## Ideia principal para guardar

- **Classe (POO)** = a "receita" de como é um Produto (`Produto.cs`).
- **Objeto** = um produto de verdade criado a partir dessa receita
  (ex: `new Produto { Nome = "Mouse Gamer", ... }`).
- **Page + Frame** = forma moderna de trocar telas *dentro* da mesma janela,
  em vez de abrir várias janelas soltas.
- **Window separada** = usada só quando você realmente quer uma janela nova
  por cima (pop-up), como um formulário de cadastro.

## Próximos passos sugeridos (para você praticar)

- Criar um botão "Adicionar Produto" que abra a `JanelaNova` como formulário
  de cadastro de verdade, e depois atualizar a lista da `DataGrid`.
- Criar uma classe `Cliente.cs` (igual foi feito com `Produto.cs`) e uma
  `PaginaClientes.xaml` seguindo o mesmo padrão da `PaginaProdutos`.
