using System.Windows;

namespace SistemaFullStackApp
{
    public partial class JanelaNova : Window
    {
        public JanelaNova()
        {
            InitializeComponent();
        }

        private void btnFechar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
