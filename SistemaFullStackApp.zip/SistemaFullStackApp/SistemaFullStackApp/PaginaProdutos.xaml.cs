using System.Collections.Generic;
using System.Windows.Controls;

namespace SistemaFullStackApp
{
    public partial class PaginaProdutos : Page
    {
        public PaginaProdutos()
        {
            InitializeComponent();
            CarregarProdutos();
        }

        private void CarregarProdutos()
        {

            List<Produto> listaProdutos = new List<Produto>
            {
                new Produto { Id = 1, Nome = "Teclado Mecânico", Preco = 250.00m, Estoque = 15 },
                new Produto { Id = 2, Nome = "Mouse Gamer", Preco = 120.50m, Estoque = 30 },
                new Produto { Id = 3, Nome = "Monitor 24' IPS", Preco = 899.90m, Estoque = 8 }
            };

            
            dgProdutos.ItemsSource = listaProdutos;
        }
    }
}
