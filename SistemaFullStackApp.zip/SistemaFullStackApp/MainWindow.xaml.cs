using System.Windows;

namespace SistemaFullStackApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            // Carrega a tela inicial por padrão ao abrir o programa
            MainFrame.Navigate(new PaginaHome());
        }

        private void btnMenuHome_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new PaginaHome());
        }

        private void btnMenuProdutos_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new PaginaProdutos());
        }

        // PASSO 5 - Exemplo de como abrir uma janela separada (pop-up/modal)
        private void btnAbrirNovaJanela_Click(object sender, RoutedEventArgs e)
        {
            JanelaNova telaModal = new JanelaNova();

            // .ShowDialog() abre como modal (bloqueia a janela de trás até fechar)
            telaModal.ShowDialog();

            // Se preferir abrir sem bloquear a janela de trás, use:
            // telaModal.Show();
        }
    }
}
