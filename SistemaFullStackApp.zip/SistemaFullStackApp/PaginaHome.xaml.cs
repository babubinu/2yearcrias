using System.Windows.Controls;

namespace SistemaFullStackApp
{
    public partial class PaginaHome : Page
    {
        public PaginaHome()
        {
            InitializeComponent();
        }
    }
}
