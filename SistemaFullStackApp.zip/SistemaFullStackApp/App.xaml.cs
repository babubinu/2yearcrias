using System.Windows;

namespace SistemaFullStackApp
{
    // Classe principal da aplicação.
    // O WPF já cuida de criar e mostrar a MainWindow sozinho,
    // por isso essa classe fica praticamente vazia.
    public partial class App : Application
    {
    }
}
