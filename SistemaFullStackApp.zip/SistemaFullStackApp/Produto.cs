namespace SistemaFullStackApp
{
    // PASSO 1.2 - Classe de Modelo (POO)
    // Essa classe representa "o que é um Produto" dentro do nosso sistema.
    // Cada propriedade é uma característica que todo produto vai ter.
    public class Produto
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
        public decimal Preco { get; set; }
        public int Estoque { get; set; }
    }
}
