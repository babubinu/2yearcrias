using System.Collections.Generic;
using System.Windows.Controls;

namespace SistemaFullStackApp
{
    public partial class PaginaJogos : Page
    {
        public PaginaJogos()
        {
            InitializeComponent();
            CarregarJogos();
        }

        private void CarregarJogos()
        {

            List<Jogos> listaJogos = new List<Jogos>
            {
                new Jogos { Id = 1, Nome = "Minecraft", Preco = 100.00m, Estoque = 15 },
                new Jogos { Id = 2, Nome = "Pokemon Go", Preco = 39.90m, Estoque = 30 },
                new Jogos { Id = 3, Nome = "The Last Of Us", Preco = 249.99m, Estoque = 8 },
                new Jogos { Id = 4 , Nome = "GTA VI", Preco = 880.00m, Estoque = 30}
            };


            dgJogos.ItemsSource = listaJogos;
        }
    }
}
