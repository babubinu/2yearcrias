﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using OdontoTech.Data;
using OdontoTech.Models;

namespace OdontoTech
{
    /// <summary>
    /// Interação lógica para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void txtEmail_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnEntrar_Click(object sender, RoutedEventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string senha = txtSenha.Password.Trim();

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(senha))
            {
                MessageBox.Show("Preencha e-mail e senha.");
                return;
            }

            try
            {
                using (var db = new AppDbContext())
                {
                    var usuario = db.Usuarios
                        .FirstOrDefault(u => u.Email == email && u.Senha == senha);

                    if (usuario != null)
                    {
                        DashboardWindow dashboard = new DashboardWindow(usuario.Nome);
                        dashboard.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show(
                            "E-mail ou senha incorretos. Tente novamente!",
                            "Acesso Negado",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);
                        txtSenha.Clear();
                        txtSenha.Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao conectar no SQL Server LocalDB:\n{ex.Message}",
                    "Falha no Banco",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }
    }
}