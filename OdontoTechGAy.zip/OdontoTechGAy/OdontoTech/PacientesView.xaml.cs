using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Microsoft.Win32;

namespace OdontoTech
{
    public partial class PacientesView : UserControl
    {
        private readonly ObservableCollection<Paciente> _lista;
        private Paciente? _selecionado;
        private string? _fotoPendente;   // caminho original da foto escolhida, ainda não copiada

        public PacientesView()
        {
            InitializeComponent();
            _lista = new ObservableCollection<Paciente>(PacienteRepository.Carregar());
            grid.ItemsSource = _lista;
            MostrarFoto(null);
        }

        // ---------- Foto ----------
        private void SelecionarFoto_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                Title = "Selecionar foto do paciente",
                Filter = "Imagens|*.jpg;*.jpeg;*.png;*.bmp;*.gif"
            };
            if (dlg.ShowDialog() != true) return;

            _fotoPendente = dlg.FileName;
            try
            {
                var img = new System.Windows.Media.Imaging.BitmapImage();
                img.BeginInit();
                img.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
                img.UriSource = new Uri(dlg.FileName);
                img.EndInit();
                img.Freeze();
                MostrarFoto(img);
            }
            catch
            {
                _fotoPendente = null;
                MessageBox.Show("Não foi possível abrir a imagem.", "Erro", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void MostrarFoto(System.Windows.Media.ImageSource? img)
        {
            if (img == null)
            {
                elFoto.Fill = null;
                lblSemFoto.Visibility = Visibility.Visible;
            }
            else
            {
                elFoto.Fill = new ImageBrush(img) { Stretch = Stretch.UniformToFill };
                lblSemFoto.Visibility = Visibility.Collapsed;
            }
        }

        // ---------- Ações ----------
        private void Salvar_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                MessageBox.Show("Informe o nome completo.", "Atenção", MessageBoxButton.OK, MessageBoxImage.Information);
                txtNome.Focus();
                return;
            }

            string arquivo = _selecionado?.ArquivoImagem ?? "";

            if (_fotoPendente != null)
            {
                Directory.CreateDirectory(Paciente.PastaImagens);
                arquivo = $"cli_{Guid.NewGuid().ToString("N")[..8]}{Path.GetExtension(_fotoPendente)}";
                File.Copy(_fotoPendente, Path.Combine(Paciente.PastaImagens, arquivo), true);
            }

            if (_selecionado == null)
            {
                _lista.Add(new Paciente
                {
                    Codigo = _lista.Count == 0 ? 1 : _lista.Max(p => p.Codigo) + 1,
                    Nome = txtNome.Text.Trim(),
                    Telefone = txtTelefone.Text.Trim(),
                    Email = txtEmail.Text.Trim(),
                    ArquivoImagem = arquivo
                });
            }
            else
            {
                _selecionado.Nome = txtNome.Text.Trim();
                _selecionado.Telefone = txtTelefone.Text.Trim();
                _selecionado.Email = txtEmail.Text.Trim();
                _selecionado.ArquivoImagem = arquivo;
                grid.Items.Refresh();
            }

            PacienteRepository.Salvar(_lista);
            LimparCampos();
        }

        private void Excluir_Click(object sender, RoutedEventArgs e)
        {
            if (_selecionado == null)
            {
                MessageBox.Show("Selecione um paciente na lista para excluir.", "Atenção",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var r = MessageBox.Show($"Excluir o paciente \"{_selecionado.Nome}\"?", "Confirmação",
                MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (r != MessageBoxResult.Yes) return;

            _lista.Remove(_selecionado);
            PacienteRepository.Salvar(_lista);
            LimparCampos();
        }

        private void Limpar_Click(object sender, RoutedEventArgs e) => LimparCampos();

        private void LimparCampos()
        {
            _selecionado = null;
            _fotoPendente = null;
            txtNome.Clear();
            txtTelefone.Clear();
            txtEmail.Clear();
            grid.UnselectAll();
            MostrarFoto(null);
            txtNome.Focus();
        }

        private void Grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (grid.SelectedItem is not Paciente p) return;
            _selecionado = p;
            _fotoPendente = null;
            txtNome.Text = p.Nome;
            txtTelefone.Text = p.Telefone;
            txtEmail.Text = p.Email;
            MostrarFoto(p.Foto);
        }
    }
}
