using System.Windows;

namespace OdontoTech
{
    public partial class App : Application { }
}
