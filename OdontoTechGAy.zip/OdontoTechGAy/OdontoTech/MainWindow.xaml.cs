using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace OdontoTech
{
    public partial class MainWindow : Window
    {
        private readonly PacientesView _pacientes = new();

        public MainWindow()
        {
            InitializeComponent();
            Conteudo.Content = _pacientes;   // abre direto em Gerenciamento de Pacientes
        }

        private void Pacientes_Click(object sender, RoutedEventArgs e) => Conteudo.Content = _pacientes;
        private void Agendamentos_Click(object sender, RoutedEventArgs e) => Conteudo.Content = Placeholder("Agendamentos");
        private void Procedimentos_Click(object sender, RoutedEventArgs e) => Conteudo.Content = Placeholder("Procedimentos");

        private void Sair_Click(object sender, RoutedEventArgs e)
        {
            var login = new LoginWindow();
            Application.Current.MainWindow = login;
            login.Show();
            Close();
        }

        private static UIElement Placeholder(string titulo) => new TextBlock
        {
            Text = $"{titulo} — em construção",
            FontSize = 22,
            Foreground = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center
        };
    }
}
