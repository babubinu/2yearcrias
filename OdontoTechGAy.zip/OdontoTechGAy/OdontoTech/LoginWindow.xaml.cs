using System.Windows;
using System.Windows.Input;

namespace OdontoTech
{
    public partial class LoginWindow : Window
    {
        // TROQUE por validação real (banco de dados) quando quiser.
        private const string EmailValido = "admin@odontotech.com";
        private const string SenhaValida = "123456";

        public LoginWindow()
        {
            InitializeComponent();
            txtEmail.Focus();
        }

        private void Entrar_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtEmail.Text) || string.IsNullOrEmpty(txtSenha.Password))
            {
                MostrarErro("Informe o e-mail e a senha.");
                return;
            }

            if (txtEmail.Text.Trim().Equals(EmailValido, StringComparison.OrdinalIgnoreCase)
                && txtSenha.Password == SenhaValida)
            {
                var principal = new MainWindow();
                Application.Current.MainWindow = principal;
                principal.Show();
                Close();
            }
            else
            {
                MostrarErro("E-mail ou senha inválidos.");
                txtSenha.Clear();
                txtSenha.Focus();
            }
        }

        private void txtSenha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) Entrar_Click(sender, e);
        }

        private void MostrarErro(string msg)
        {
            lblErro.Text = msg;
            lblErro.Visibility = Visibility.Visible;
        }

        private void Fechar_Click(object sender, RoutedEventArgs e) => Application.Current.Shutdown();

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed) DragMove();
        }
    }
}
