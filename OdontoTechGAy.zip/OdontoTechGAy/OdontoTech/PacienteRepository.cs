using System.IO;
using System.Text.Json;

namespace OdontoTech
{
    public static class PacienteRepository
    {
        private static readonly string Arquivo = Path.Combine(AppContext.BaseDirectory, "pacientes.json");
        private static readonly JsonSerializerOptions Opcoes = new() { WriteIndented = true };

        public static List<Paciente> Carregar()
        {
            try
            {
                if (!File.Exists(Arquivo)) return new();
                return JsonSerializer.Deserialize<List<Paciente>>(File.ReadAllText(Arquivo)) ?? new();
            }
            catch { return new(); }
        }

        public static void Salvar(IEnumerable<Paciente> pacientes)
        {
            File.WriteAllText(Arquivo, JsonSerializer.Serialize(pacientes, Opcoes));
        }
    }
}
