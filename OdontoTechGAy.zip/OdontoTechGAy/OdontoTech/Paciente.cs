using System.IO;
using System.Text.Json.Serialization;
using System.Windows.Media.Imaging;

namespace OdontoTech
{
    public class Paciente
    {
        public int Codigo { get; set; }
        public string Nome { get; set; } = "";
        public string Telefone { get; set; } = "";
        public string Email { get; set; } = "";
        public string ArquivoImagem { get; set; } = "";   // só o nome do arquivo

        [JsonIgnore]
        public BitmapImage? Foto => Carregar(ArquivoImagem);

        public static string PastaImagens => Path.Combine(AppContext.BaseDirectory, "Imagens");

        public static BitmapImage? Carregar(string? nomeArquivo)
        {
            if (string.IsNullOrWhiteSpace(nomeArquivo)) return null;
            var caminho = Path.Combine(PastaImagens, nomeArquivo);
            if (!File.Exists(caminho)) return null;
            try
            {
                var img = new BitmapImage();
                img.BeginInit();
                img.CacheOption = BitmapCacheOption.OnLoad;   // não trava o arquivo
                img.UriSource = new Uri(caminho);
                img.DecodePixelWidth = 200;
                img.EndInit();
                img.Freeze();
                return img;
            }
            catch { return null; }
        }
    }
}
